import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { IconTile } from '@/components/shared/icon-tile'
import { IllustrationPlaceholder } from '@/components/shared/illustration-placeholder'
import { LandingHeader } from '@/components/shared/landing-header'
import { LandingFooter } from '@/components/shared/landing-footer'
import { categoryIcons, whyKerjaIn, matchingSteps } from '@/lib/landing-content'
import { Search, MapPin, Package, Handshake, Sparkles, ArrowRight } from 'lucide-react'

export default async function LandingPage() {
  const supabase = await createClient()

  const { data: categories } = await supabase
    .from('categories')
    .select('id, name')
    .eq('is_active', true)

  const { data: featuredUmkm } = await supabase
    .from('umkm_profiles')
    .select('user_id, business_name, service_area, trust_score, description')
    .order('trust_score', { ascending: false })
    .limit(4)

  return (
    <div className="min-h-screen bg-background">
      <LandingHeader />

      {/* Hero */}
      <section className="mx-auto max-w-6xl px-6 py-16 md:py-24">
        <div className="grid gap-12 md:grid-cols-2 md:items-center">
          <div>
            <Badge variant="secondary" className="mb-4">Solo Raya · SDG 8 Decent Work</Badge>
            <h1 className="text-4xl font-bold leading-tight tracking-tight md:text-5xl">
              Temukan UMKM & Pekerja Lepas Terpercaya
            </h1>
            <p className="mt-4 text-muted-foreground">
              KerjaIn menghubungkan kamu dengan UMKM dan pekerja lepas terverifikasi di Solo Raya —
              didukung skor reputasi yang transparan dan rekomendasi AI yang bisa dijelaskan.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/search"><Button size="lg">Cari Layanan</Button></Link>
              <Link href="/register"><Button size="lg" variant="outline">Daftarkan Usaha Anda</Button></Link>
            </div>
            <div className="mt-10 flex flex-wrap gap-8">
              <div>
                <p className="text-2xl font-bold">{categories?.length ?? 0}</p>
                <p className="text-sm text-muted-foreground">Kategori Aktif</p>
              </div>
              <div>
                <p className="text-2xl font-bold">Transparan</p>
                <p className="text-sm text-muted-foreground">Trust Score Terverifikasi</p>
              </div>
              <div>
                <p className="text-2xl font-bold">Explainable</p>
                <p className="text-sm text-muted-foreground">Rekomendasi AI</p>
              </div>
            </div>
          </div>

          <IllustrationPlaceholder icon={Handshake} label="Ilustrasi Hero" />
        </div>

        {/* Floating search bar */}
        <form action="/search" method="get" className="mt-8 flex flex-col gap-2 rounded-xl bg-card p-2 ring-1 ring-foreground/10 md:flex-row">
          <div className="flex flex-1 items-center gap-2 px-3">
            <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
            <Input
              name="q"
              placeholder="Jasa atau barang apa yang kamu cari?"
              className="border-0 shadow-none focus-visible:ring-0"
            />
          </div>
          <div className="flex items-center gap-2 border-t px-3 pt-2 md:border-l md:border-t-0 md:pt-0">
            <MapPin className="h-4 w-4 shrink-0 text-muted-foreground" />
            <Input
              name="location"
              placeholder="Lokasi"
              className="border-0 shadow-none focus-visible:ring-0 md:w-40"
            />
          </div>
          <Button type="submit" className="w-full md:w-auto md:shrink-0">Cari</Button>
        </form>
      </section>

      {/* Browse by category */}
      <section id="categories" className="border-t bg-muted/20 py-16">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="mb-8 text-2xl font-bold">Jelajahi Kategori</h2>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {(categories ?? []).map((cat) => {
              const Icon = categoryIcons[cat.name] ?? Package
              return (
                <Link key={cat.id} href={`/search?category=${cat.id}`}>
                  <Card className="h-full transition-all hover:-translate-y-0.5 hover:shadow-md">
                    <CardContent className="flex flex-col items-center gap-3 py-8 text-center">
                      <IconTile icon={Icon} />
                      <p className="text-sm font-medium">{cat.name}</p>
                    </CardContent>
                  </Card>
                </Link>
              )
            })}
          </div>
        </div>
      </section>

      {/* Featured UMKM */}
      <section className="py-16">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="mb-8 text-2xl font-bold">UMKM Pilihan</h2>

          {(!featuredUmkm || featuredUmkm.length === 0) && (
            <Card className="border-dashed">
              <CardContent className="py-10 text-center text-sm text-muted-foreground">
                Belum ada UMKM terdaftar — jadilah yang pertama.{' '}
                <Link href="/register" className="underline">Daftarkan usaha kamu</Link>
              </CardContent>
            </Card>
          )}

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {featuredUmkm?.map((u) => (
              <Link key={u.user_id} href={`/umkm/${u.user_id}`}>
                <Card className="h-full transition-all hover:-translate-y-0.5 hover:shadow-md">
                  <CardContent className="pt-6">
                    <p className="font-medium">{u.business_name}</p>
                    <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                      <MapPin className="h-3 w-3" />{u.service_area}
                    </p>
                    <Badge variant="secondary" className="mt-3">Trust Score {u.trust_score ?? 0}/100</Badge>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why KerjaIn */}
      <section className="border-t bg-muted/20 py-16">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="mb-8 text-2xl font-bold">Kenapa KerjaIn</h2>
          <div className="grid gap-8 md:grid-cols-3">
            {whyKerjaIn.map((item) => (
              <div key={item.title}>
                <IconTile icon={item.icon} className="mb-4" />
                <h3 className="font-medium">{item.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Smart Matching */}
      <section id="how-it-works" className="py-16">
        <div className="mx-auto grid max-w-6xl gap-12 px-6 md:grid-cols-2 md:items-center">
          <IllustrationPlaceholder icon={Sparkles} label="Ilustrasi Matching" className="order-2 md:order-1" />
          <div className="order-1 md:order-2">
            <h2 className="mb-4 text-2xl font-bold">Cari Lewat AI Assistant</h2>
            <ol className="space-y-4">
              {matchingSteps.map((step, i) => (
                <li key={i} className="flex items-start gap-3">
                  <IconTile icon={step.icon} size="sm" />
                  <span className="pt-1 text-sm">{step.text}</span>
                </li>
              ))}
            </ol>
            <Link href="/ai-chat">
              <Button className="mt-6">
                Coba AI Matching<ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <LandingFooter />
    </div>
  )
}
