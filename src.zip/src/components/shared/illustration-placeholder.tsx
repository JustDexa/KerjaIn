import type { LucideIcon } from 'lucide-react'

export function IllustrationPlaceholder({
  icon: Icon,
  label,
  className = '',
}: {
  icon: LucideIcon
  label: string
  className?: string
}) {
  return (
    <div className={`flex aspect-square items-center justify-center rounded-xl border bg-muted/30 ${className}`}>
      <div className="text-center text-muted-foreground">
        <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-full border bg-background">
          <Icon className="h-7 w-7" />
        </div>
        <p className="text-sm">{label}</p>
      </div>
    </div>
  )
}
